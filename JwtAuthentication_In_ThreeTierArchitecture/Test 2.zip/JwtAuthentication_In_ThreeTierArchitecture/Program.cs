using JwtAuthentication_In_ThreeTierArchitecture.model;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
var domain = $"https://{builder.Configuration["Jwt:Domains"]}/";
builder.Services.AddAuthentication(options=>
    {
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
}).AddJwtBearer(Options=>
{
    Options.Authority = builder.Configuration["Jwt:Authority"];
    Options.Audience = builder.Configuration["Jwt:Audience"];
   // Options.SecretKey = builder.Configuration["jwt:SecretKey"];
    Options.RequireHttpsMetadata = false;
});



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();

app.MapControllers();

app.Run();
