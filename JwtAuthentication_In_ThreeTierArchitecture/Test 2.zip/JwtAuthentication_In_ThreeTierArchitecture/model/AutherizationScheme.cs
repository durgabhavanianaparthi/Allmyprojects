﻿namespace JwtAuthentication_In_ThreeTierArchitecture.model
{
    public class AutherizationScheme
    {
        public const string Jwt = "Jwt";
    }
}
